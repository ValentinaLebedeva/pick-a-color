/*
Задание:
Сделать рабочий фильтр цветов.
При нажатии на один из цветов, круг с цветом - мы видим автомобиль, соответствующего цвета.
А активный цвет выделяется, за счет дополнительного CSS класса ".colorItem--active".

Работу сдать через CodePen.

Другие изображения автомобиля:
https://webcademy.ru/files/js2020/solaris/black.png
https://webcademy.ru/files/js2020/solaris/blue.png
https://webcademy.ru/files/js2020/solaris/graphite.png
https://webcademy.ru/files/js2020/solaris/orange.png
https://webcademy.ru/files/js2020/solaris/red.png
https://webcademy.ru/files/js2020/solaris/white.png
https://webcademy.ru/files/js2020/solaris/white-pure.png
*/
var colorsSelector = document.querySelector("#colorsSelector");
colorsSelector.addEventListener("click", changeColor);

function changeColor(e) {
    var chosenColor = document.querySelector(".colorItem--active");
    var color = e.target.getAttribute("data-color");
    if (e.target.classList.contains("colorItem")) {
        e.target.classList.add("colorItem--active");
        chosenColor.classList.remove("colorItem--active");

        document.querySelector("#imgHolder").firstElementChild.setAttribute("src", `https://webcademy.ru/files/js2020/solaris/${color}.png`);
    }
}
